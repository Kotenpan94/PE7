﻿using System;

namespace PE07GoldsteenMahala
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
